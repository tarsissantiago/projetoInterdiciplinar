package br.faccamp.util;

import br.faccamp.domain.Calculadora;

public class CalculadoraMain {
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
	}
}
