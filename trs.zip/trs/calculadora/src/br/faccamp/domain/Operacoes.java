package br.faccamp.domain;

import br.faccamp.view.CalculadoraGUI;

public class Operacoes {
	
	CalculadoraGUI gui;

public  Operacoes (CalculadoraGUI gui){
	this.gui=gui;
}


	public void soma(double a, double b){
		String texto=String.valueOf(a+b);
		gui.atualizaDisplay(texto);
	}

	public void subtracao(double a, double b){
			
		}

	public void multipicacao(double a, double b){
		
	}

	public void divisao(double a, double b){
		
	}

	public void fatorial(double a, double b){
		
	}

	public void raiz(double a, double b){
		
	}

}
