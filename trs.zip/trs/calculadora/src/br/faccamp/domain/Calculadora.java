package br.faccamp.domain;

import br.faccamp.view.CalculadoraGUI;

public class Calculadora {
	
	Operacoes op;
	private CalculadoraGUI gui;
	private Display display;

	public Calculadora() {
		gui = new CalculadoraGUI(this);
		display = new Display(gui);
		op = new Operacoes(gui);
	}

	// Numeros

	public void processaZero() {
		display.atualiza("0");
	}

	public void processaUm() {
		display.atualiza("1");
	}

	public void processaDois() {
		display.atualiza("2");
	}

	public void processaTres() {
		display.atualiza("3");
	}

	public void processaQuatro() {
		display.atualiza("4");
	}

	public void processaCinco() {
		display.atualiza("5");
	}

	public void processaSeis() {
		display.atualiza("6");
	}

	public void processaSete() {
		display.atualiza("7");
	}

	public void processaOito() {
		display.atualiza("8");
	}

	public void processaNove() {
		display.atualiza("9");
	}

	
	// Opera�oes
	
	public void processaRaiz() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('r');
	}

	public void processaMaisOuMenos() {
		// TODO Auto-generated method stub

	}

	public void processaFatorial() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('r');

	}

	public void processaDivisao() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('/');
	}

	public void processaPorcentual() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('%');
	}

	public void processaVezes() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('*');
	}

	public void processaUmSobreX() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('x');
	}

	public void processaMenos() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('-');
	}

	public void processaXElevadoY() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('e');
	}

	public void processaVirgula() {
		display.atualiza(",");
	}

	public void processaIgual() {
		display.salvaB();
		display.calcula();

	}

	public void processaLog() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('l');
	}

	public void processaMais() {
		display.salvaA();
		display.zeraDisplay();
		display.setOpera��o('+');
	}

	
	// memoria & fun�oes calculadora
	
	public void processaMC() {
		// TODO Auto-generated method stub

	}

	public void processaMR() {
		// TODO Auto-generated method stub

	}

	public void processaMS() {
		// TODO Auto-generated method stub

	}

	public void processaMMais() {
		// TODO Auto-generated method stub

	}

	public void processaMMenos() {
		// TODO Auto-generated method stub

	}

	public void processaCE() {
		// TODO Auto-generated method stub

	}

	public void processaC() {
		// TODO Auto-generated method stub

	}

	
}
