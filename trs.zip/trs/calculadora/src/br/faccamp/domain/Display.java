package br.faccamp.domain;

import br.faccamp.view.CalculadoraGUI;

public class Display {

	private CalculadoraGUI gui;
	private double a, b,r;
	private char operador;

	public Display(CalculadoraGUI gui) {
		this.gui = gui;
	}

	public void atualiza(String texto) {
		if (getConteudo().equalsIgnoreCase("")) {
			gui.atualizaDisplay(texto);
		} else {
			gui.atualizaDisplay((getConteudo() + texto));
		}

	}

	private String getConteudo() {
		return gui.getDisplay();
	}

	public void salvaA() {
		setA( Double.parseDouble(getConteudo()));
	}

	public void zeraDisplay() {
		gui.atualizaDisplay("");
	}

	public void setOpera��o(char operador) {
		this.operador = operador;
	}

	public char getOperador() {
		return operador;
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public void salvaB() {
		setB(Double.parseDouble(getConteudo()));
		
	}
	public void calcula() {
		switch (operador)
		{
		case ('+'):  r=a+b;  break;
		case ('-'):  r=a-b;  break;
		case ('*'):  r=a*b;  break;
		case ('/'):  r=a/b;  break;
				
		}
	gui.atualizaDisplay(String.valueOf(r));
	}

}


